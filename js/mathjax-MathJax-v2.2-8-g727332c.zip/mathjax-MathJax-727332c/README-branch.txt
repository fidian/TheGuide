This is release branch v2.2 of MathJax.
